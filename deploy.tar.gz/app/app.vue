<template>
  <UApp>
    <NuxtPage />
  </UApp>
</template>
