#!/bin/bash

# Deploy Finance App to Digital Ocean Droplet
set -e

# Configuration
REMOTE_HOST="root@kwoo-cloud-1"
REMOTE_PATH="/opt/finance-app"
LOCAL_PATH="."

echo "🚀 Starting deployment to Digital Ocean..."

# Build the application locally (optional - can also build on server)
echo "📦 Building application locally..."
npm run build

# Create deployment package
echo "📋 Creating deployment package..."
tar --exclude-from=.deployignore -czf deploy.tar.gz .

# Copy files to server
echo "📤 Uploading files to server..."
ssh $REMOTE_HOST "mkdir -p $REMOTE_PATH"
scp deploy.tar.gz $REMOTE_HOST:$REMOTE_PATH/

# Deploy on server
echo "🔧 Deploying on server..."
ssh $REMOTE_HOST << EOF
    cd $REMOTE_PATH
    
    # Stop existing containers
    docker compose -f docker-compose.prod.yml down || true
    
    # Extract new files
    tar -xzf deploy.tar.gz
    rm deploy.tar.gz
    
    # Create data directory
    mkdir -p data
    
    # Build and start containers
    docker compose -f docker-compose.prod.yml up -d --build
    
    # Clean up old images
    docker image prune -f
    
    echo "✅ Deployment complete!"
    echo "📊 Container status:"
    docker compose -f docker-compose.prod.yml ps
EOF

# Clean up local files
rm -f deploy.tar.gz

echo "🎉 Deployment to Digital Ocean completed successfully!"
echo "🌐 Your app should be accessible at: http://kwoo-cloud-1:7654"