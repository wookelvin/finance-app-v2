#!/bin/bash

# Server management script
REMOTE_HOST="root@kwoo-cloud-1"
REMOTE_PATH="/opt/finance-app"

case "$1" in
    "logs")
        echo "📋 Viewing application logs..."
        ssh $REMOTE_HOST "cd $REMOTE_PATH && docker compose -f docker-compose.prod.yml logs -f finance-app"
        ;;
    "status")
        echo "📊 Checking application status..."
        ssh $REMOTE_HOST "cd $REMOTE_PATH && docker compose -f docker-compose.prod.yml ps"
        ;;
    "restart")
        echo "🔄 Restarting application..."
        ssh $REMOTE_HOST "cd $REMOTE_PATH && docker compose -f docker-compose.prod.yml restart"
        ;;
    "stop")
        echo "🛑 Stopping application..."
        ssh $REMOTE_HOST "cd $REMOTE_PATH && docker compose -f docker-compose.prod.yml down"
        ;;
    "start")
        echo "▶️ Starting application..."
        ssh $REMOTE_HOST "cd $REMOTE_PATH && docker compose -f docker-compose.prod.yml up -d"
        ;;
    "shell")
        echo "🐚 Connecting to application container..."
        ssh $REMOTE_HOST "cd $REMOTE_PATH && docker compose -f docker-compose.prod.yml exec finance-app sh"
        ;;
    "ssh")
        echo "🔗 SSH into server..."
        ssh $REMOTE_HOST
        ;;
    *)
        echo "Usage: $0 {logs|status|restart|stop|start|shell|ssh}"
        echo ""
        echo "Commands:"
        echo "  logs    - View application logs"
        echo "  status  - Check container status"
        echo "  restart - Restart the application"
        echo "  stop    - Stop the application"
        echo "  start   - Start the application"
        echo "  shell   - Open shell in app container"
        echo "  ssh     - SSH into the server"
        exit 1
        ;;
esac