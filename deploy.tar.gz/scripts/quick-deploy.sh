#!/bin/bash

# Quick deployment script for fast updates
set -e

REMOTE_HOST="root@kwoo-cloud-1"
REMOTE_PATH="/opt/finance-app"

echo "⚡ Quick deployment (code changes only)..."

# Create a minimal package with just the code changes
tar --exclude-from=.deployignore -czf quick-deploy.tar.gz \
    app/ composables/ server/ prisma/schema.prisma nuxt.config.ts package.json

# Upload and deploy
scp quick-deploy.tar.gz $REMOTE_HOST:$REMOTE_PATH/

ssh $REMOTE_HOST << EOF
    cd $REMOTE_PATH
    
    # Extract files
    tar -xzf quick-deploy.tar.gz
    rm quick-deploy.tar.gz
    
    # Restart containers
    docker compose -f docker-compose.prod.yml restart
    
    echo "✅ Quick deployment complete!"
    docker compose -f docker-compose.prod.yml ps
EOF

rm -f quick-deploy.tar.gz
echo "🎉 Quick deployment completed!"