#!/bin/bash

# Test connection to Digital Ocean server
set -e

REMOTE_HOST="root@kwoo-cloud-1"

echo "🔍 Testing connection to Digital Ocean server..."

# Test SSH connectivity
if ssh -o ConnectTimeout=10 -o BatchMode=yes $REMOTE_HOST 'echo "SSH connection successful"'; then
    echo "✅ SSH connection: OK"
else
    echo "❌ SSH connection: FAILED"
    echo "Please check:"
    echo "  - Server is running"
    echo "  - SSH keys are configured"
    echo "  - Hostname/IP is correct"
    exit 1
fi

# Check Docker installation
echo "🐳 Checking Docker installation..."
if ssh $REMOTE_HOST 'docker --version && docker compose version'; then
    echo "✅ Docker: OK"
else
    echo "❌ Docker: Not installed or not accessible"
    echo "Please install Docker on your server"
    exit 1
fi

# Check available disk space
echo "💾 Checking disk space..."
ssh $REMOTE_HOST 'df -h /'

# Check if port 7654 is available
echo "🔌 Checking if port 7654 is available..."
if ssh $REMOTE_HOST 'netstat -tuln | grep :7654'; then
    echo "⚠️  Port 7654 is already in use"
else
    echo "✅ Port 7654: Available"
fi

echo ""
echo "🎉 Server connectivity test completed!"
echo "You can now run: npm run deploy"