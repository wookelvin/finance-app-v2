Connecting to Digital Ocean

```
ssh root@kwoo-cloud-1
```

Updating packages

```
sudo apt update && sudo apt upgrade -y
```

System restart
```
sudo reboot
```

